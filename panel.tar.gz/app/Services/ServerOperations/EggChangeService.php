<?php

namespace Pterodactyl\Services\ServerOperations;

use Exception;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Permission;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Jobs\Server\ApplyEggChangeJob;
use Illuminate\Auth\Access\AuthorizationException;
use Pterodactyl\Services\Subdomain\SubdomainManagementService;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Service for handling server egg configuration changes.
 *
 * Manages egg previews, validation, and asynchronous application of egg changes
 * including backup creation and file management.
 */
class EggChangeService
{
    public function __construct(
        private ServerOperationService $operationService,
        private ServerStateValidationService $validationService,
        private SubdomainManagementService $subdomainService
    ) {}

    /**
     * Preview egg change information.
     */
    public function previewEggChange(Server $server, int $eggId, int $nestId): array
    {
        $this->validationService->validateServerState($server);
        
        $egg = Egg::query()
            ->with(['variables', 'nest'])
            ->findOrFail($eggId);
        
        if ($egg->nest_id !== $nestId) {
            throw new BadRequestHttpException(__('exceptions.server_operations.egg_not_in_nest'));
        }
        
        $variables = $egg->variables()->orderBy('name')->get();
        $dockerImages = $egg->docker_images ?? [];
        
        // Check subdomain compatibility
        $subdomainWarning = $this->checkSubdomainCompatibility($server, $egg);
        
        $result = [
            'egg' => [
                'id' => $egg->id,
                'name' => e($egg->name),
                'description' => e($egg->description),
                'startup' => $egg->startup,
            ],
            'variables' => $variables->map(function ($variable) {
                return [
                    'id' => $variable->id,
                    'name' => e($variable->name),
                    'description' => e($variable->description),
                    'env_variable' => $variable->env_variable,
                    'default_value' => $variable->default_value,
                    'user_viewable' => $variable->user_viewable,
                    'user_editable' => $variable->user_editable,
                    'rules' => $variable->rules,
                ];
            }),
            'docker_images' => $dockerImages,
            'default_docker_image' => !empty($dockerImages) ? array_keys($dockerImages)[0] : null,
        ];
        
        // Add subdomain warning if applicable
        if ($subdomainWarning) {
            $result['warnings'] = [$subdomainWarning];
        }
        
        return $result;
    }

    /**
     * Validate egg change parameters.
     */
    public function validateEggChangeParameters(
        Server $server,
        int $eggId,
        int $nestId,
        ?string $dockerImage = null,
        ?string $startupCommand = null
    ): array {
        $this->validationService->validateCanAcceptOperation($server, 'egg_change');
        
        $egg = Egg::query()
            ->with(['variables', 'nest'])
            ->findOrFail($eggId);
        
        if ($egg->nest_id !== $nestId) {
            throw new BadRequestHttpException(__('exceptions.server_operations.egg_not_in_nest'));
        }
        
        $startupCommand = $startupCommand ? trim($startupCommand) : null;
        $dockerImage = $dockerImage ? trim($dockerImage) : null;
        
        if ($startupCommand && strlen($startupCommand) > 2048) {
            throw new BadRequestHttpException(__('exceptions.server_operations.startup_command_too_long'));
        }
        
        if ($dockerImage) {
            $allowedImages = array_values($egg->docker_images ?? []);
            if (!empty($allowedImages) && !in_array($dockerImage, $allowedImages)) {
                throw new BadRequestHttpException(__('exceptions.server_operations.docker_image_not_allowed'));
            }
        }
        
        if (!$dockerImage && !empty($egg->docker_images)) {
            $dockerImage = array_values($egg->docker_images)[0];
        }
        
        return [
            'egg' => $egg,
            'docker_image' => $dockerImage,
            'startup_command' => $startupCommand,
        ];
    }

    /**
     * Apply egg change asynchronously.
     */
    public function applyEggChangeAsync(
        Server $server,
        User $user,
        int $eggId,
        int $nestId,
        ?string $dockerImage = null,
        ?string $startupCommand = null,
        array $environment = [],
        bool $shouldBackup = false,
        bool $shouldWipe = false
    ): array {
        $validated = $this->validateEggChangeParameters(
            $server,
            $eggId,
            $nestId,
            $dockerImage,
            $startupCommand
        );

        $this->assertPermissions(
            $server,
            $user,
            $validated['egg'],
            $dockerImage,
            $validated['startup_command'],
            $environment,
            $shouldBackup,
            $shouldWipe
        );

        $dockerImage = $validated['docker_image'];
        $startupCommand = $validated['startup_command'];
        
        $operation = $this->operationService->createOperation(
            $server,
            $user,
            'egg_change',
            [
                'from_egg_id' => $server->egg_id,
                'to_egg_id' => $eggId,
                'from_nest_id' => $server->nest_id,
                'to_nest_id' => $nestId,
                'docker_image' => $dockerImage,
                'startup_command' => $startupCommand,
                'environment' => $environment,
                'should_backup' => $shouldBackup,
                'should_wipe' => $shouldWipe,
            ]
        );
        
        try {
            ApplyEggChangeJob::dispatch(
                $server,
                $user,
                $eggId,
                $nestId,
                $dockerImage,
                $startupCommand,
                $environment,
                $shouldBackup,
                $shouldWipe,
                $operation->operation_id
            );
        } catch (Exception $e) {
            $operation->delete();
            
            Log::error('Failed to dispatch egg change job', [
                'server_id' => $server->id,
                'operation_id' => $operation->operation_id,
                'error' => $e->getMessage(),
            ]);
            
            throw new \RuntimeException(__('exceptions.server_operations.queue_failed'));
        }
        
        return [
            'message' => __('exceptions.server_operations.egg_change_queued'),
            'operation_id' => $operation->operation_id,
            'status' => 'pending',
        ];
    }

    private function assertPermissions(
        Server $server,
        User $user,
        Egg $egg,
        ?string $dockerImage,
        ?string $startupCommand,
        array $environment,
        bool $shouldBackup,
        bool $shouldWipe
    ): void {
        $deny = fn () => throw new AuthorizationException();

        if (!is_null($dockerImage) && !$user->can(Permission::ACTION_STARTUP_DOCKER_IMAGE, $server)) {
            $deny();
        }

        if (!empty($startupCommand) && trim($startupCommand) !== trim((string) $egg->startup) && !$user->can(Permission::ACTION_STARTUP_COMMAND, $server)) {
            $deny();
        }

        if (!empty($environment) && !$user->can(Permission::ACTION_STARTUP_UPDATE, $server)) {
            $deny();
        }

        if (!$user->can(Permission::ACTION_SETTINGS_REINSTALL, $server)) {
            $deny();
        }

        if ($shouldBackup && !$user->can(Permission::ACTION_BACKUP_CREATE, $server)) {
            $deny();
        }

        if ($shouldWipe && (!$user->can(Permission::ACTION_FILE_READ, $server) || !$user->can(Permission::ACTION_FILE_DELETE, $server))) {
            $deny();
        }
    }

    /**
     * Check if changing to the new egg will affect subdomain compatibility.
     */
    private function checkSubdomainCompatibility(Server $server, Egg $newEgg): ?array
    {
        // Check if server currently has an active subdomain
        $activeSubdomain = $server->activeSubdomain;
        
        if (!$activeSubdomain) {
            return null; // No subdomain to worry about
        }
        
        // Check if the current egg supports subdomains
        $currentSupportsSubdomain = $server->supportsSubdomains();
        
        if (!$currentSupportsSubdomain) {
            return null; // Current egg doesn't support subdomains anyway
        }
        
        // Create a temporary server instance with the new egg to test compatibility
        $tempServer = clone $server;
        $tempServer->egg = $newEgg;
        $tempServer->egg_id = $newEgg->id;
        
        // Check if the new egg supports subdomains
        $newSupportsSubdomain = $tempServer->supportsSubdomains();
        
        if (!$newSupportsSubdomain) {
            return [
                'type' => 'subdomain_incompatible',
                'message' => __('exceptions.server_operations.subdomain_incompatible', ['subdomain' => $activeSubdomain->full_domain]),
                'severity' => 'warning',
            ];
        }
        
        return null; // New egg supports subdomains, no warning needed
    }
}